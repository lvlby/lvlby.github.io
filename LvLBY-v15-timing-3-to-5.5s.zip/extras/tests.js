const fs=require('fs');const s=fs.readFileSync('index.html','utf8');
const js=[...s.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(x=>x[1]).join('\n');
let P=0,F=0;const K=(n,c,x)=>{if(c){P++;console.log('ok   '+n)}else{F++;console.log('FAIL '+n+(x?' | '+x:''))}};
const ex=n=>{const i=js.indexOf(n),j=js.indexOf('\n',i);return js.slice(i,j)};
// 1. no duplicate top-level declarations for new names
const block=js.slice(js.indexOf('/* ---- v10:'),js.indexOf('function toast(msg)'));
const names=[...block.matchAll(/^(?:function|const|let)\s+([A-Za-z_$][\w$]*)/gm)].map(m=>m[1]);
const dup=names.filter(n=>(js.match(new RegExp('^(?:async )?(?:function|const|let)\\s+'+n.replace(/\$/g,'\\$')+'\\b','gm'))||[]).length>1);
K('no duplicate top-level declarations for the new code ('+names.length+' names)',dup.length===0,dup.join());
// 2. harness
const shiftDays=(d,n)=>{const x=new Date(d+'T12:00:00Z');x.setUTCDate(x.getUTCDate()+n);return x.toISOString().slice(0,10)};
let TODAY='2026-10-24';const env={};
const pre=[ex('function dayNum'),ex('function satWeek'),ex('function dayDone'),ex('function isVac'),ex('const XPW'),ex('function xpDay'),ex('function xpTotal'),ex('function lvlOf'),ex('function streakFrom'),ex('function streakNow')].join('\n');
function make(data0,S0){
  const f=new Function('data','S','today','shiftDays','L','fa','l2','displayTaskName','notif','toast','obEl','$','save','renderAll','buildDay','showStatus','cloudUser','cloudReady','cloudAuth','saveS','syncSettings','TOUR',
   pre+'\n'+block+'\n;return{habitStats,dailyChallenges,chalState,coinsEarned,coinsSpent,coinBalance,petStage,petMood,petFace,buildICS,weekActive,icsEsc,allHabits,habFill}');
  return f(data0,S0,()=>TODAY,shiftDays,(a,b)=>a,x=>String(x),a=>a[0],it=>it.name,{lead:5},()=>{},()=>({}),()=>({}),()=>{},()=>{},()=>{},()=>{},null,false,null,()=>{},()=>{},[]);
}
// 3. habit stats
const water={id:'water',name:'Drink water',time:'07:00'};
const data={routine:[{id:'morning',items:[water,{id:'gym',name:'Gym, "hard";',time:'18:00',days:[1,3]}]}],schedule:{},weeks:[],days:{},exams:[],vac:[]};
const mk=(d,done)=>({tasks:[{id:d+'-water',kind:'routine',done}],built:true});
// 24 Oct is today; done on 24(pending), 23,22,21, missed 20, done 19,18
data.days['2026-10-18']=mk('2026-10-18',true);data.days['2026-10-19']=mk('2026-10-19',true);data.days['2026-10-20']=mk('2026-10-20',false);
data.days['2026-10-21']=mk('2026-10-21',true);data.days['2026-10-22']=mk('2026-10-22',true);data.days['2026-10-23']=mk('2026-10-23',true);data.days['2026-10-24']=mk('2026-10-24',false);
const S0={pet:'cat',pname:'',owned:[],hat:''};let api=make(data,S0);
let h=api.habitStats(water);
K('habit streak: current = 3 (today still pending, missed day breaks older run)',h.cur===3,JSON.stringify(h.cur));
K('habit streak: best = 3',h.best===3,String(h.best));
K('habit rate over scheduled days = 83% (5 done of 6; pending today not counted)',h.rate===83,String(h.rate));
K('habit dots: 14 entries, last 6 days match data',h.dots.length===14&&h.dots[12]===true&&h.dots[9]===false,JSON.stringify(h.dots.slice(7)));
data.days['2026-10-24'].tasks[0].done=true;h=make(data,S0).habitStats(water);K('today done extends streak to 4',h.cur===4,String(h.cur));
data.vac=[{from:'2026-10-20',to:'2026-10-20'}];h=make(data,S0).habitStats(water);K('vacation day does not break the habit streak (now 6)',h.cur===6,String(h.cur));data.vac=[];
const gym=data.routine[0].items[1];K('weekday-limited habit without data returns zeros safely',make(data,S0).habitStats(gym).cur===0);
// habit counter fill
data.days['2026-10-24'].tasks[0].done=true;water.target=3;K('ticking a counter habit fills its count',(()=>{const a=make(data,S0);const ch=a.habFill();return ch&&data.days['2026-10-24'].tasks[0].count===3})());water.target=1;
// 4. challenges
const a2=make({routine:[],schedule:{},weeks:[],days:{}},S0);let allOk=true,diff=new Set(),same=true;
for(let i=0;i<300;i++){const d=shiftDays('2026-01-01',i),c=a2.dailyChallenges(d),ids=c.map(x=>x.def.id);if(new Set(ids).size!==3)allOk=false;diff.add(ids.join());const c2=a2.dailyChallenges(d);if(c2.map(x=>x.def.id+x.n).join()!==c.map(x=>x.def.id+x.n).join())same=false}
K('daily challenges: always 3 different ones (300 dates)',allOk);K('daily challenges: same date always gives the same set',same);K('daily challenges vary between days ('+diff.size+' different sets)',diff.size>20);
// 5. coins derive from real data and never go negative
const d5={routine:[],schedule:{},weeks:[],days:{'2026-10-24':{tasks:[{id:'a',kind:'custom',done:true,priority:'high'},{id:'b',kind:'custom',done:true},{id:'c',kind:'custom',done:true}],built:true}},exams:[],vac:[]};
const S5={pet:'cat',pname:'',owned:[],hat:''};const a5=make(d5,S5);const e0=a5.coinsEarned();
K('coins earned is a whole number >= 0',Number.isInteger(e0)&&e0>=0,String(e0));
S5.owned=['crown','top'];K('spent = sum of owned item prices (110)',a5.coinsSpent()===110);K('balance never negative',a5.coinBalance()===Math.max(0,e0-110)&&a5.coinBalance()>=0);
d5.days['2026-10-24'].tasks.forEach(t=>t.done=false);K('un-checking tasks lowers coins (no farming)',make(d5,S5).coinsEarned()<=e0);
// 6. pet
const ap=make(data,S0);K('pet stages by level (1->egg, 2-3->baby, 4-6->teen, 7+->adult)',[1,2,3,4,6,7,20].map(ap.petStage).join()==='0,1,1,2,2,3,3');
K('pet face uses chosen species and only OWNED hat',(()=>{const S6={pet:'dragon',pname:'',owned:['bow'],hat:'crown'};const f=make(data,S6).petFace();return f.hat===''&&f.em.length>0})());
K('pet face shows an owned, equipped hat',make(data,{pet:'fox',pname:'',owned:['crown'],hat:'crown'}).petFace().hat==='👑');
// 7. calendar file
const ics=make({routine:[{id:'m',items:[{id:'w',name:'Water, now; ok',time:'07:00'},{id:'g',name:'Gym',time:'18:30',days:[1,3]},{id:'n',name:'No time'},{id:'arch',name:'Old',time:'09:00',archived:true}]}],schedule:{},weeks:[],days:{'2026-10-25':{tasks:[{id:'x1',kind:'custom',name:'Call mom',time:'17:00',done:false}],built:true}},exams:[{id:'e1',title:'Math',date:'2026-10-30',type:'exam',done:false}],vac:[]},S0).buildICS();
const t=ics.text;K('ics: valid wrapper and CRLF line ends',t.startsWith('BEGIN:VCALENDAR\r\n')&&t.trimEnd().endsWith('END:VCALENDAR')&&!/[^\r]\n/.test(t));
K('ics: 4 events (2 habits + 1 task + 1 exam), skipping no-time and archived',(t.match(/BEGIN:VEVENT/g)||[]).length===4&&ics.count===4);
K('ics: balanced VEVENT/VALARM blocks',(t.match(/BEGIN:VEVENT/g)||[]).length===(t.match(/END:VEVENT/g)||[]).length&&(t.match(/BEGIN:VALARM/g)||[]).length===(t.match(/END:VALARM/g)||[]).length&&(t.match(/BEGIN:VALARM/g)||[]).length===4);
K('ics: daily habit RRULE, weekly BYDAY for Mon/Wed',t.includes('RRULE:FREQ=DAILY')&&t.includes('RRULE:FREQ=WEEKLY;BYDAY=MO,WE'));
K('ics: gym starts on the next Monday/Wednesday (Wed 28 Oct is next from Sat 24)',t.includes('DTSTART:20261026T183000')||t.includes('DTSTART:20261028T183000'),'');
K('ics: special characters escaped (comma and semicolon)',t.includes('SUMMARY:Water\\, now\\; ok'));
K('ics: alarm uses reminder lead (5 min) and exam alarm 1 day before',t.includes('TRIGGER:-PT5M')&&t.includes('TRIGGER:-P1D'));
K('ics: all-day exam date format',t.includes('DTSTART;VALUE=DATE:20261030'));
// 8. settings keys fit the Firestore rules
const rules=fs.readFileSync('firestore.rules','utf8');const allowed=(rules.match(/settings\.keys\(\)\.hasOnly\(\[([^\]]*)\]/)[1].match(/'([a-zA-Z]+)'/g)||[]).map(x=>x.replace(/'/g,''));
const Sdef=js.match(/let S=\{([^}]*)\}/)[1].split(',').map(x=>x.split(':')[0].trim());
K('every default setting key is allowed by the rules',Sdef.every(k=>allowed.includes(k)),Sdef.filter(k=>!allowed.includes(k)).join());
// 9. source checks for the connection work and model patches
K('connection: SDK loader has a backup source and a retry hook',s.includes('cdn.jsdelivr.net/npm/firebase@10.14.1')&&s.includes('window.fbLoad='));
K('connection: Firestore long-polling auto-detect enabled',js.includes('experimentalAutoDetectLongPolling:true'));
K('connection: exponential backoff replaces the fixed 15 s retry',js.includes('Math.pow(2,Math.min(retryN++,5))')&&!js.includes('setTimeout(pushCloud,15000)'));
K('connection: friendly VPN message wired into sign-in errors',js.includes("sx('needvpn')")&&js.includes("sx('waitg')"));
K('buildDay keeps count/top/subs and skips archived habits',js.includes('count:old.find')&&js.includes('.filter(it=>!it.archived)'));
const tabs=new Set([...s.matchAll(/data-view="([a-z]+)"/g)].map(m=>m[1]));K('pet tab and view exist',tabs.has('pet')&&s.includes('id="view-pet"'));
console.log('\nV10 TESTS: '+P+' passed, '+F+' failed');

// ================= v11 tests: onboarding version, routine builder, non-student, colours =================
let P2=0,F2=0;const Q=(n,c,x)=>{if(c){P2++;console.log('ok   '+n)}else{F2++;console.log('FAIL '+n+(x?' | '+x:''))}};
const qsSrc=js.slice(js.indexOf('const ONB_VER'),js.indexOf('const OB='));
const QSx=new Function(qsSrc+';return{QS,ONB_VER}')();const QS2=QSx.QS;
Q('onboarding version is defined',QSx.ONB_VER===2);
Q('16 questions, unique keys, every one has an icon',QS2.length===16&&new Set(QS2.map(q=>q.k)).size===16&&QS2.every(q=>q.i),QS2.length+' questions');
Q('only name and student stay required',QS2.filter(q=>q.req).map(q=>q.k).join()==='name,student');
Q('new questions exist and are bilingual',['energy','dayType'].every(k=>{const q=QS2.find(x=>x.k===k);return q&&q.q[0]&&q.q[1]&&q.o[0].length===q.o[1].length}));
Q('calendar question is still the last one',QS2[QS2.length-1].k==='cal');
Q('first run and "first run after an update" both start the questions',js.includes("if(!profileOk()||P.ov!==ONB_VER)setTimeout(()=>obStart(false,profileOk()),700)"));
Q('finishing the questions saves the version number',js.includes('P={done:true,ov:ONB_VER};'));
Q('signing in with an older saved profile re-asks the questions',/function afterSignIn\(\)\{[^\n]*P\.ov!==ONB_VER/.test(js));
const rules2=fs.readFileSync('firestore.rules','utf8');const allowedP=(rules2.match(/profile\.keys\(\)\.hasOnly\(\[([^\]]*)\]/)[1].match(/'([a-zA-Z]+)'/g)||[]).map(x=>x.replace(/'/g,''));
const keysP=js.match(/\['name','goal','student','work'[^\]]*\]/)[0].match(/'([a-zA-Z]+)'/g).map(x=>x.replace(/'/g,''));
Q('every profile key the app syncs is allowed by the rules',keysP.every(k=>allowedP.includes(k)),keysP.filter(k=>!allowedP.includes(k)).join());
Q('flow order: questions -> routine ready -> Google suggestion -> finish',js.includes("ob.plan=plan;ob.stage='ready'")&&js.includes("if(!ob.edit&&!cloudUser){ob.stage='connect'")&&js.includes("if(ob.stage==='ready')return renderReady(box)"));
Q('old routine is backed up before the personal setup runs',/plan=pzBuild\(\);backupDevice\(\);pzApply\(plan\)/.test(js));
// routine builder with stubs
const pzSrc=js.slice(js.indexOf('const pzFmt'),js.indexOf('function pzApply'));
function buildFor(Pv){const mkdata=()=>({routine:[{id:'morning',titleKey:'m',items:[{id:'bed',time:'06:55'},{id:'brush-am',time:'07:00'},{id:'wash-am',time:'07:05'},{id:'water',time:'07:08'}]},{id:'evening',titleKey:'e',items:[{id:'brush-pm',time:'21:45'},{id:'wash-pm',time:'22:00'},{id:'prepare',time:'22:10'}]}],schedule:{morning:[{id:'wake',time:'06:30'}],afternoon:[{id:'wake',time:'06:30'}],off:[{id:'wake',time:'06:30'}]}});
  const dat=mkdata();const f=new Function('P','data','L','lang',pzSrc+';return pzBuild');const list=f(Pv,dat,(a)=>a,'en')();return{list,dat}}
const stu=buildFor({student:true,goal:0,wake:1,sleep:2,challenge:[2],interests:[6],energy:2,dayType:0,daily:3});
Q('routine builder returns items with icon, title and time text',stu.list.length>=3&&stu.list.every(a=>a.ic&&a.t&&a.d));
Q('habit count respects the daily-time budget (max 5 extras)',stu.list.filter(a=>a.id.startsWith('h-')).length<=5);
stu.list.forEach(a=>a.run());const mg=stu.dat.routine[0].items.map(i=>i.id);
Q('evening energy puts the 25-minute focus habit at 19:00',stu.dat.routine[1].items.some(i=>i.id==='pz-focus'&&i.time==='19:00'));
const wk=buildFor({student:false,goal:1,wake:2,sleep:3,challenge:[],interests:[],energy:0,dayType:2,daily:3});wk.list.forEach(a=>a.run());
Q('work-from-home answer adds the walk break',wk.dat.routine.some(g=>g.items.some(i=>i.id==='pz-walk')));
Q('morning energy + work goal adds a deep-work block',wk.dat.routine.some(g=>g.items.some(i=>i.id==='pz-deep'&&i.time==='10:00')),JSON.stringify(wk.dat.routine.map(g=>g.items.map(i=>i.id+'@'+i.time))));
const early=buildFor({student:false,wake:0,sleep:3,daily:1});early.list.forEach(a=>a.run());Q('an early wake-up (5:30) moves the default morning habits earlier (bed 05:55)',early.dat.routine[0].items.find(i=>i.id==='bed').time==='05:55',early.dat.routine[0].items.find(i=>i.id==='bed').time);
Q('two different people get different routines',JSON.stringify(stu.dat.routine)!==JSON.stringify(wk.dat.routine));
const none=buildFor({student:false,wake:undefined,sleep:undefined,daily:0});Q('empty answers still give a safe result (no crash)',Array.isArray(none.list)&&none.list.length>=1);
// non-student gating
Q('"No" to student turns shifts off everywhere',js.includes("function notStudent(){try{return P.student===false}catch(e){return false}}")&&js.includes("function activeShift(date){if(notStudent())return 'off'"));
Q('shift switch is hidden in Settings for non-students',js.includes("lab.hidden=notStudent()"));
Q('tour skips the schedule step for non-students',js.includes("TOUR.filter(x=>!(notStudent()&&x.tab==='schedule'))"));
// colours and contrast
const cssAll=s.match(/<style>([\s\S]*?)<\/style>/g).join('\n');
Q('palette has 7 accent colours instead of 2',['--violet','--pink','--orange','--teal','--yellow','--blue','--red'].every(v=>cssAll.includes(v+':')));
Q('muted text is brighter than before (contrast)',cssAll.includes('--muted:#b6c3d8'));
Q('each tab has its own colour',['today','habits','schedule','calendar','pet','reports'].every(v=>cssAll.includes('.tab[data-view='+v+'].active')));
Q('task rows carry kind and priority classes',js.includes("' k-'+(t.kind||'x')+' p-'+(t.priority||'normal')")&&cssAll.includes('.task.k-school'));
console.log('\nV11 TESTS: '+P2+' passed, '+F2+' failed');
